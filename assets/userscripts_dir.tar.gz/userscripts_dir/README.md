See the `/userscripts_dir` section of the [README.md](../README.md) for details.

This directory is used to run independent user scripts in order to perform additional operations that might damage your installation. 
**Use with caution**. No support will be provided for issues resulting from the use of this directory. In case of trouble, it is recommended to delete the `run` folder and start a new container.

In general, most higher numbered scripts should be run after `00-nvidiaDev.sh` which checks for the presence of `nvcc`.
